package com.application;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConsoleApplicationTests {

	@Test
	void contextLoads() {
	}

}
